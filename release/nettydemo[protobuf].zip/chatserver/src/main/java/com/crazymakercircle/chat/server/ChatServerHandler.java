package com.crazymakercircle.chat.server;


import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("ChatServerHandler")
public class ChatServerHandler extends ChannelInboundHandlerAdapter
{
    static final Logger LOGGER = LoggerFactory.getLogger(ChatServerHandler.class);

    /**
     * 建立连接时
     */
    @Override
    public void channelActive(final ChannelHandlerContext ctx) {
        LOGGER.info("CHANNEL_ACTIVE " + ctx.channel().remoteAddress());

    }
    /**
     * 收到消息
     * @param ctx
     * @param msg
     */
    public void channelRead(ChannelHandlerContext ctx, Object msg)
    {
       LOGGER.info("msg:{}",msg.toString());

       ctx.writeAndFlush(msg);

    }


}
