package com.crazymakercircle.nettydemo.client;


import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.CharsetUtil;
import io.netty.util.ReferenceCountUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("echoClientHandler")
public class EchoClientHandler extends ChannelInboundHandlerAdapter
{

    static final Logger LOGGER = LoggerFactory.getLogger(EchoClientHandler.class);

    /**
     * 此方法会在连接到服务器后被调用
     */
    public void channelActive(ChannelHandlerContext ctx)
    {
        ctx.writeAndFlush(Unpooled.copiedBuffer("无编程不创客，无创客不编程!", CharsetUtil.UTF_8));
    }

    /**
     * 业务逻辑处理
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception
    {
        // 如果不是protobuf类型的数据
        if (!(msg instanceof ByteBuf))
        {
            LOGGER.info("未知数据!" + msg);
            return;
        }
        try
        {
            ByteBuf in = (ByteBuf) msg;

            if (!in.hasArray())
            {
                int len = in.readableBytes();
                byte[] arr = new byte[len];
                in.getBytes(0, arr);

                LOGGER.info("Client received: " + new String(arr));
            }


        } catch (Exception e)
        {
            e.printStackTrace();
        } finally
        {
            ReferenceCountUtil.release(msg);
        }


    }

    /**
     * 捕捉到异常
     */
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
    {
        cause.printStackTrace();
        ctx.close();
    }

}
