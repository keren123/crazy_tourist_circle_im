package com.crazymakercircle.nettydemo.server;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("echoServerHandler")
public class EchoServerHandler extends ChannelInboundHandlerAdapter
{
    static final Logger LOGGER = LoggerFactory.getLogger(EchoServerHandler.class);

    /**
     * 建立连接时，发送一条消息
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception
    {
        LOGGER.info("连接的客户端地址:" + ctx.channel().remoteAddress());
        super.channelActive(ctx);
    }

    public void channelRead(ChannelHandlerContext ctx, Object msg)
    {
        ByteBuf in = (ByteBuf) msg;
        if (!in.hasArray())
        {
            int len = in.readableBytes();
            byte[] arr = new byte[len];
            in.getBytes(0, arr);

            LOGGER.info("server received: " + new String(arr));
        }

        ctx.writeAndFlush(msg);//写回数据，
    }

    public void channelReadComplete(ChannelHandlerContext ctx)
    {
        //flush掉所有写回的数据
//        ctx.writeAndFlush(Unpooled.EMPTY_BUFFER);
        //当flush完成后关闭channel
        //        .addListener(ChannelFutureListener.CLOSE);
    }

    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
    {
        //捕捉异常信息
        cause.printStackTrace();
        //出现异常时关闭channel
        ctx.close();
    }
}
